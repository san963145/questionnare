package com.questionnare.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.AnswerDao;
import com.questionnare.dao.FinishedListDao;
import com.questionnare.dao.PaperDao;
import com.questionnare.dao.QuestionDao;
import com.questionnare.model.Paper;
import com.questionnare.model.Question;
import com.questionnare.util.Generator;

/**
 * Servlet implementation class ReceiveAnswer
 */
@WebServlet("/ReceiveAnswer")
public class ReceiveAnswer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReceiveAnswer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ServletContext application=(ServletContext) request.getServletContext();
		String paperID=(String)application.getAttribute("paperID");
		String openID=(String)request.getParameter("openID");
		boolean isFinished=FinishedListDao.isFinished(paperID, openID);
		if(isFinished){
			send(request,response,paperID,openID,"repeated");
			return;
		}
		Map<String,ArrayList<String>> questions=QuestionDao.getTypeAndQuestionIDByPaperID(paperID);
		Map<String,String> answers=new HashMap<String,String>();
		ArrayList<String> singles=questions.get("1");
		if(singles!=null)
		for(String s:singles){
			String answer=(String)request.getParameter(s);
			if(answer==null){
				send(request,response,paperID,openID,"notComplete");
				return ;
			}
			answers.put(s, answer);
		}
		ArrayList<String> multis=questions.get("2");
		if(multis!=null)
		for(String s:multis){
			String[] values=request.getParameterValues(s);			
			if(values==null){
				send(request,response,paperID,openID,"notComplete");
				return ;
			}
			String answer=new String();
			for(int i=0;i<values.length;i++){
				if(i<values.length-1)
				    answer+=values[i]+",";
				else
					answer+=values[i];
			}
			answers.put(s, answer);
		}
		ArrayList<String> blanks=questions.get("3");
		if(blanks!=null)
		for(String s:blanks){
			String answer=(String)request.getParameter(s);
			if(answer==null){
				send(request,response,paperID,openID,"notComplete");
				return ;
			}else if(answer.trim().length()==0){
				send(request,response,paperID,openID,"notComplete");
				return ;
			}
			answers.put(s, answer);
		}
		for(Entry<String,String>entry:answers.entrySet()){
			String question=entry.getKey();
			String answer=entry.getValue();
			AnswerDao.add(question, openID, answer);
		}
		FinishedListDao.add(paperID, openID);
		send(request,response,paperID,openID,"success");
		return ;
	}
	private void send(HttpServletRequest request,HttpServletResponse response,String paperID,String openID,String result) throws ServletException, IOException{
		Paper paper=PaperDao.getPaperByPaperID(paperID);
		ArrayList<Question> questions=QuestionDao.getQuestionsByPaperID(paperID);
	    String fullPaper=Generator.generateFullPaper(paper,questions);
	    request.setAttribute("paperID",paperID);
	    request.setAttribute("openID",openID);
	    request.setAttribute("title",paper.getTitle());
	    request.setAttribute("description",paper.getDescription());
	    request.setAttribute("fullPaper",fullPaper);
		request.setAttribute("result", result);
		request.getRequestDispatcher("pages/paper.jsp").forward(request, response);
	}

}
