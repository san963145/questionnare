package com.questionnare.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.PaperDao;
import com.questionnare.dao.QuestionDao;
import com.questionnare.model.Paper;

/**
 * Servlet implementation class AddBlank
 */
@WebServlet("/AddBlank")
public class AddBlank extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBlank() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String title=request.getParameter("title");
		String paperID=request.getParameter("paperID");
		Paper paper=PaperDao.getPaperByPaperID(paperID);
		boolean isRepeated=QuestionDao.get(title, "3");
		if(isRepeated){
			request.setAttribute("result","repeat");
			request.getRequestDispatcher("pages/addBlank.jsp").forward(request, response);
			return;
		}
		String empty="";
		boolean addResult=QuestionDao.add(title, "3", empty, empty, empty, empty, empty, empty, paperID);
	    if(addResult){
	    	request.setAttribute("result","success");
	    	request.setAttribute("paperID",paperID);
			request.setAttribute("title",paper.getTitle());
			request.setAttribute("description",paper.getDescription());
			request.getRequestDispatcher("pages/editNew.jsp").forward(request, response);
			return;
	    }else{
	    	request.setAttribute("result","error");
			request.getRequestDispatcher("pages/addBlank.jsp").forward(request, response);
			return;
	    }
	}

}
