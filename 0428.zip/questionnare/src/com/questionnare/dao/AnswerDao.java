package com.questionnare.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AnswerDao {
	
	public static boolean add(String questionID,String openID,String answer)
	{	
		Connection conn=ConnManager.getConnection();
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try
		{
			PreparedStatement ps = conn.prepareStatement("insert into answer(questionID,openID,answer) values(?,?,?)");
			ps.setString(1, questionID);
			ps.setString(2, openID);
			ps.setString(3, answer);
			ps.execute();
			conn.commit();
			return true;
		}  catch(Exception e)
		  {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return false;
	}
	public static void main(String[] args){
		String s="123.23456";
		int a=s.indexOf('.');
        if(a!=-1&&a<s.length()-3)
		s=s.substring(0,a+3);
		System.out.println(s);
	}
	public static ArrayList<ArrayList<String>> getListByQuestionID(String questionID)
	{	
		Connection conn=ConnManager.getConnection();
		ArrayList<ArrayList<String>>result=new ArrayList<ArrayList<String>>();
		try
		{
			int total=getCountByQuestionID(questionID);
			if(total==0)
				return result;
			PreparedStatement ps = conn.prepareStatement("select a.questionID questionID,a.answer answer,COUNT(*) count from answer a where questionID=? group by a.questionID,a.answer;");
			ps.setString(1, questionID);
			ps.execute();
			ResultSet rs=ps.getResultSet();			
			while(rs.next())
			{
				ArrayList<String> list=new ArrayList<String>();
				String answer=rs.getString("answer");
				Integer count=rs.getInt("count");
				Float r=(float)count/(float)total*(float)100.0;
				String rate=r.toString();
				int a=rate.indexOf('.');
				if(a!=-1&&a<rate.length()-3){
					rate=rate.substring(0,a+3);
				}
				rate=rate+"%";
                list.add(answer);
                list.add(count.toString());	
                list.add(rate);	
				result.add(list);
			}	
		}  catch(Exception e)
		  {
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return result;
	}
	public static int getCountByQuestionID(String questionID)
	{	
		Connection conn=ConnManager.getConnection(); 
		try
		{
			PreparedStatement ps = conn.prepareStatement("select count(*) count from answer where questionID=?");
			ps.setString(1, questionID);
			ps.execute();
			ResultSet rs=ps.getResultSet();			
			if(rs.next())
			{
				int count=rs.getInt("count");
				return count;
			}	
		}  catch(Exception e)
		  {
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return 0;
	}

}
