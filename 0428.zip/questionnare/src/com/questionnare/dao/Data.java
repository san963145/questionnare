package com.questionnare.dao;

import java.util.ArrayList;

import com.questionnare.model.Paper;
import com.questionnare.model.Question;

public class Data {
	
	public static ArrayList<Paper>papers=new ArrayList<Paper>();
	
	public static ArrayList<Question>questions=new ArrayList<Question>();

}
