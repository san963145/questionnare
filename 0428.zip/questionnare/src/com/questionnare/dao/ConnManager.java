package com.questionnare.dao;

import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.Connection;

public class ConnManager {
	
	private static final String driverClass="com.microsoft.sqlserver.jdbc.SQLServerDriver";//����������
	private static final String jdbcURL="jdbc:sqlserver://apachkqpsvu0001.apac.nsroot.net:5000;databaseName=SECURITY_1";
	private static final String name="eqsmcdbo";
	private static final String pwd="Ua5Ra9PmJ";
	
	public static Connection getConnection(){
		Connection con = null;
		//������ѯ�����
		try {
			Class.forName(driverClass);//������������
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = (Connection) DriverManager.getConnection(jdbcURL, name, pwd);//���ӵ����ݿ�
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}
	public static void main(String[] args){
		System.out.println(getConnection());
	}

}
