package com.questionnare.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;


public class FinishedListDao {

	public static boolean add(String paperID,String openID)
	{	
		Connection conn=ConnManager.getConnection();
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try
		{
			PreparedStatement ps = conn.prepareStatement("insert into finishedList(paperID,openID,time) values(?,?,?)");
			ps.setString(1, paperID);
			ps.setString(2, openID);
			long t=System.currentTimeMillis();
			Timestamp time=new Timestamp(t);
			ps.setString(3, time.toString());
			ps.execute();
			conn.commit();
			return true;
		}  catch(Exception e)
		  {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return false;
	}
	
	public static int getFinishedCountByPaper(String paperID)
	{	
		Connection conn=ConnManager.getConnection(); 
		try
		{
			PreparedStatement ps = conn.prepareStatement("select count(*) count from finishedList where paperID=?");
			ps.setString(1, paperID);
			ps.execute();
			ResultSet rs=ps.getResultSet();			
			if(rs.next())
			{
				int count=rs.getInt("count");
				return count;
			}	
		}  catch(Exception e)
		  {
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return 0;
	}
	public static boolean isFinished(String paperID,String openID)
	{	
		Connection conn=ConnManager.getConnection(); 
		try
		{
			PreparedStatement ps = conn.prepareStatement("select * from finishedList where paperID=? and openID=?");
			ps.setString(1, paperID);
			ps.setString(2, openID);
			ps.execute();
			ResultSet rs=ps.getResultSet();			
			if(rs.next())
			{
				return true;
			}	
		}  catch(Exception e)
		  {
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return false;
	}

}
